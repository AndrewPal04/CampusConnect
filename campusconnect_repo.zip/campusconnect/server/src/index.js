import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

// Route imports
import authRoutes    from './routes/auth.js';
import eventRoutes   from './routes/events.js';
import rsvpRoutes    from './routes/rsvp.js';
import userRoutes    from './routes/users.js';
import uploadRoutes  from './routes/uploads.js';

import { errorHandler } from './middleware/errorHandler.js';
import { notFound }     from './middleware/notFound.js';

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Security & Middleware ─────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000' }));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

// Rate limiting — global
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200 }));

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/auth',    authRoutes);
app.use('/api/events',  eventRoutes);
app.use('/api/rsvp',    rsvpRoutes);
app.use('/api/users',   userRoutes);
app.use('/api/uploads', uploadRoutes);

// Health check
app.get('/api/health', (_, res) => res.json({ status: 'ok', env: process.env.NODE_ENV }));

// ── Error Handling ────────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🚀  CampusConnect API running on http://localhost:${PORT}`);
});

export default app;
